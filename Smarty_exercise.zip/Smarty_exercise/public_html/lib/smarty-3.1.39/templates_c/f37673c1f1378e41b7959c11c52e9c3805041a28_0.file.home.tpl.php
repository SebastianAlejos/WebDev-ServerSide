<?php
/* Smarty version 3.1.39, created on 2021-09-28 11:07:33
  from 'C:\Users\basti\Documents\Fall 2021\Webdev2\WebDev-ServerSide\Smarty_exercise\public_html\templates\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61532fb56119c9_09484347',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f37673c1f1378e41b7959c11c52e9c3805041a28' => 
    array (
      0 => 'C:\\Users\\basti\\Documents\\Fall 2021\\Webdev2\\WebDev-ServerSide\\Smarty_exercise\\public_html\\templates\\home.tpl',
      1 => 1632841652,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61532fb56119c9_09484347 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
</head>
<body>
    <h1>My First Smarty Pants Page</h1>
    <p> This works</p>
</body>
</html><?php }
}
